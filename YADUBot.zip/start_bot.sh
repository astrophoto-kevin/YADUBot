#!/bin/sh

python3 YADUBot.py
